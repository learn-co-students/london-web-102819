puts 'hello, this works cause my computer can run ruby'

